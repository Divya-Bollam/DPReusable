package crud.restservices.services;


import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.intThat;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.h2.command.dml.MergeUsing.When;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import org.springframework.security.crypto.password.PasswordEncoder;

import crud.restservices.entity.Employee;
import crud.restservices.model.EmployeeServiceImpl;
import crud.restservices.repository.EmployeeRepository;


@ExtendWith(MockitoExtension.class)
public class EmployeeServiceTests {

	@Mock
	private EmployeeRepository employeeRepository;

	@InjectMocks
	private EmployeeServiceImpl employeeServiceImpl;
	
	@Mock
	private PasswordEncoder passwordEncoder;

	private Employee employee1;

	private Employee employee2;

	@BeforeEach
	void before() {
		employee1 = new Employee();
		employee1.setId(1);
		employee1.setEmpId("z004admin");
		employee1.setEmpName("Admin");
		employee1.setPassword("admin");
		employee1.setEmpType("admin");
		employee1.setSalary(25000);

		employee2 = new Employee();
		employee2.setId(2);
		employee2.setEmpId("z004user");
		employee2.setEmpName("User");
		employee2.setPassword("user");
		employee2.setEmpType("USER");
		employee2.setSalary(20000);
	}

	@Test
	void create() {
		when(employeeRepository.save(any(Employee.class))).thenReturn(employee1);
		Employee newEmployee = employeeServiceImpl.createEmployee(employee1);
		assertNotNull(newEmployee);
		assertThat(newEmployee.getEmpId()).isEqualTo("z004admin");
	}
	
	
	@Test
	void getAllEmployees() {
		
		List<Employee> list = new ArrayList<>();
		list.add(employee1);
		list.add(employee2);
		
		when(employeeRepository.findAll()).thenReturn(list);
		List<Employee> employees = employeeServiceImpl.getAllEmployees();
		
		assertEquals(2, employees.size());
		assertNotNull(employees);
	}
	
	@Test
	void getEmployeeById() {
		when(employeeRepository.findById(anyInt())).thenReturn(Optional.of(employee1));
		Employee existingEmployee = employeeServiceImpl.getEmployeeById(employee1.getId());
		assertNotNull(existingEmployee);
		assertThat(existingEmployee.getId()).isNotEqualTo(null);
	}
	
	@Test
	void updateEmployee() {
		when(employeeRepository.findById(anyInt())).thenReturn(Optional.of(employee1));
		when(employeeRepository.save(any(Employee.class))).thenReturn(employee1);
		
		employee1.setEmpName("ADMIN");
		Employee exisitingEmployee = employeeServiceImpl.updateEmployee(employee1, employee1.getId());
		
		assertNotNull(exisitingEmployee);
		assertEquals("ADMIN", employee1.getEmpName());
	}
	
	@Test
	void deleteEmployee() {

		 int empId = 1;
		 when(employeeRepository.findById(anyInt())).thenReturn(Optional.of(employee1));
		 doNothing().when(employeeRepository).delete(any(Employee.class));
		 employeeServiceImpl.deleteEmployee(empId);
		 verify(employeeRepository, times(1)).delete(employee1);
		
	}
}
