package crud.restservices.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.net.URI;
import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.ResponseEntity;

import crud.restservices.entity.Employee;
import crud.restservices.model.EmployeeService;
import crud.restservices.model.EmployeeServiceImpl;


@ExtendWith(MockitoExtension.class)
public class EmployeeControllerTests {
	
	private EmployeeController employeeController;
	
	@Test
	void createEmployee() {
		employeeController = new EmployeeController();
		
		//Preparing the Mock
		EmployeeService empService = Mockito.mock(EmployeeServiceImpl.class);
		employeeController.setEmployeeService(empService);
		
		// Preparing the data
		Employee expectEmp = new Employee();
		expectEmp.setId(0);
		
		Employee emp = new Employee();
		emp.setId(0);
		
		// Set data to mock object
		Mockito.when(empService.createEmployee(emp)).thenReturn(emp);
		
		// Calling actual method
		URI uri = null;
		ResponseEntity <Employee> result = employeeController.createEmployee(emp,uri);
		
		// Asserting
		
		assertEquals(result.getBody().getId(), expectEmp.getId());
	}
	
	@Test
	void getAllEmployees() {
		employeeController = new EmployeeController();
		
		//Preparing the Mock
		EmployeeService empService = Mockito.mock(EmployeeServiceImpl.class);
		employeeController.setEmployeeService(empService);
		
		// Preparing the data
		Employee expectEmp = new Employee();
		expectEmp.setId(0);
		
		Employee emp = new Employee();
		emp.setId(0);
		
		// Set data to mock object
		List <Employee> emps = new ArrayList <>();
		
		emps.add(emp);
		
		Mockito.when(empService.getAllEmployees()).thenReturn(emps);
		
		
		// Calling actual method
		ResponseEntity<List<Employee>> result = employeeController.getAllEmployees();
		
		// Asserting
		assertEquals(result.getBody().get(0).getId(),expectEmp.getId());
	}
	
	@Test
	void getEmployeeById() {
		employeeController = new EmployeeController();
		
		//Preparing the Mock
		EmployeeService empService = Mockito.mock(EmployeeServiceImpl.class);
		employeeController.setEmployeeService(empService);
		
		// Preparing the data
		Employee expectEmp = new Employee();
		expectEmp.setId(0);
		
		Employee emp = new Employee();
		emp.setId(0);
		
		// Set data to mock object
		Mockito.when(empService.getEmployeeById(emp.getId())).thenReturn(emp);
		
		// Calling actual method
		ResponseEntity<Employee> result = employeeController.getEmployeeById(emp.getId());
		
		// Asserting
		assertEquals(result.getBody().getId(), expectEmp.getId());
	}
	
	@Test
	void updateEmployee() {
		employeeController = new EmployeeController();
		
		//Preparing the Mock
		EmployeeService empService = Mockito.mock(EmployeeServiceImpl.class);
		employeeController.setEmployeeService(empService);
		
		// Preparing the data
		Employee expectEmp = new Employee();
		expectEmp.setId(0);
		
		Employee emp = new Employee();
		emp.setId(0);
		
		// Set data to mock object
		Mockito.when(empService.updateEmployee(emp, emp.getId())).thenReturn(emp);
		
		// Calling actual method
		ResponseEntity<Employee> result = employeeController.updateEmployee(emp.getId(), emp);
				
		// Asserting
		assertEquals(result.getBody().getId(), expectEmp.getId());
	}
	
	@Test
	void deleteEmployee() {
		employeeController = new EmployeeController();
		
		// Preparing the Mock
		EmployeeService empService = Mockito.mock(EmployeeServiceImpl.class);
		employeeController.setEmployeeService(empService);
		
		// Preparing the data
		Employee emp = new Employee();
		emp.setId(0);
		
		// Calling the actual method
		employeeController.deleteEmployee(emp.getId());
		
		// Verify if the delete method is called.
		Mockito.verify(empService).deleteEmployee(emp.getId());
	}
	
}
