package crud.restservices.controller;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import java.util.List;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.boot.test.web.server.LocalServerPort;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.web.client.RestTemplate;
import crud.restservices.entity.Employee;
import crud.restservices.repository.EmployeeRepository;

@SpringBootTest(webEnvironment = WebEnvironment.RANDOM_PORT)
public class EmployeeControllerIT {
	
	@LocalServerPort
	private int port;
	
	@Autowired
	private static RestTemplate testRestTemplate;
	
	private String baseUrl = "http://localhost";
	
	@Autowired
	private EmployeeRepository employeeRepository;
	
	private Employee emp1;
	
	private Employee emp2;
	
	@BeforeAll
	static void  init() {
		testRestTemplate = new RestTemplate(); 
	}
	
	@BeforeEach
	 void setup() {
		baseUrl = baseUrl + ":" +port+"/employees";
		
		emp1 = new Employee();
		emp2 = new Employee();
		
		emp1.setEmpId("z004test");
		emp1.setEmpName("Test");
		emp1.setPassword("test");
		emp1.setEmpType("admin");
		emp1.setSalary((long) 25000);
		
		
		emp2.setEmpId("z004user");
		emp2.setEmpName("User");
		emp2.setPassword("user");
		emp2.setEmpType("USER");
		emp2.setSalary((long) 20000);
		
		emp1 = employeeRepository.save(emp1);
		emp2 = employeeRepository.save(emp2);
	}
	
	@AfterEach
	public void afterSetup() {
		employeeRepository.deleteAll();
	}
	
	
	@Test
	@WithMockUser(username = "admin", roles = "ADMIN")
	void createEmployee() {
	
        baseUrl = baseUrl + "";
		
		Employee newEmployee = testRestTemplate.postForObject(baseUrl, emp1, Employee.class);
		
		assertNotNull(newEmployee);
		assertThat(newEmployee.getId()).isNotNull();
	
	}
	
	
	@Test
	void ShouldGetEmployee() {
		baseUrl = baseUrl + "/getall";
		List<Employee> list = testRestTemplate.getForObject(baseUrl, List.class);
		
		assertNotNull(list);
		assertThat(list.size()).isEqualTo(2);
	}
	
	@Test
	void ShouldGetEmployeeById() {
		baseUrl = baseUrl + "/" + emp1.getId();
		
		Employee existingEmployee = testRestTemplate.getForObject(baseUrl, Employee.class);
		
		assertNotNull(existingEmployee);
		assertEquals("z004test", emp1.getEmpId());
	}

	@Test
	void ShouldUpdateEmployeeById() {
		
		String updateUrl = baseUrl + "/update/{empid}";
		String getbaseUrl = baseUrl +  "/" + emp1.getId();
		
		emp1.setEmpName("TEST");
		
		testRestTemplate.put(updateUrl, emp1, emp1.getId());
		Employee existingEmployee = testRestTemplate.getForObject(getbaseUrl, Employee.class);
		assertNotNull(existingEmployee);
		assertEquals("TEST", existingEmployee.getEmpName());
	}
	
	
	@Test
	void ShouldDeleteEmployee() {
		baseUrl = baseUrl + "/delete" + "/" + emp1.getId();
		
		testRestTemplate.delete(baseUrl);
		
		int count = employeeRepository.findAll().size();
		
		assertEquals(2, count);
	}

}
