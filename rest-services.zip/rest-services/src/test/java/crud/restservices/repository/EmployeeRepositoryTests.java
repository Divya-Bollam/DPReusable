package crud.restservices.repository;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;


import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.mock.mockito.MockBean;

import crud.restservices.entity.Employee;
import crud.restservices.model.EmployeeService;

@DataJpaTest
public class EmployeeRepositoryTests {
	
	@Autowired
	private EmployeeRepository employeeRepository;
	
	@MockBean
    private EmployeeService employeeService;
	
	@Test
	void create() {
		
		//Arrange
		Employee emp1 = new Employee();
		emp1.setEmpId("z004m0dh");
		emp1.setEmpName("syed");
		emp1.setPassword("admin");
		emp1.setEmpType("admin");
		emp1.setSalary(25000);
		 
		
		//Act
		Employee newEmployee = employeeRepository.save(emp1);
		
		// Assert
		assertNotNull(newEmployee);
		assertThat(newEmployee.getEmpId()).isNotEqualTo(null);
	}
	
	@Test
	void getAllEmp() {
		
		Employee emp1 = new Employee();
		emp1.setEmpId("z004m0dk");
		emp1.setEmpName("mahi");
		emp1.setPassword("user");
		emp1.setEmpType("user");
		emp1.setSalary(25000);
	 
		
		employeeRepository.save(emp1);
		
		Employee emp2 = new Employee();
		emp2.setEmpId("z004m0dn");
		emp2.setEmpName("dhoni");
		emp2.setPassword("user");
		emp2.setEmpType("user");
		emp2.setSalary(25000);
		employeeRepository.save(emp2);
		
		List <Employee> emps = employeeRepository.findAll();
		
		assertNotNull(emps);
		assertThat(emps).isNotNull();
		assertEquals(2,emps.size());
	}
	
	@Test
	void getEmpById() {
		
		Employee emp1 = new Employee();
		emp1.setEmpId("z004m0dr");
		emp1.setEmpName("raina");
		emp1.setPassword("user");
		emp1.setEmpType("user");
		emp1.setSalary(25000);
		
		
		employeeRepository.save(emp1);
		
	    Employee existingEmployee = employeeRepository.findById(emp1.getId()).get();
		
	    assertNotNull(existingEmployee);
	    assertThat(existingEmployee).isNotNull();
	    assertEquals("raina", existingEmployee.getEmpName());
		
	}
	
	@Test
	void updateEmp() {
		Employee emp1 = new Employee();
		emp1.setEmpId("z004m0db");
		emp1.setEmpName("bravo");
		emp1.setPassword("user");
		emp1.setEmpType("user");
		emp1.setSalary(25000);
		employeeRepository.save(emp1);
		
		
		Employee updatedEmp3  = employeeRepository.findById(emp1.getId()).get();
		updatedEmp3.setEmpName("Mahendra");
		employeeRepository.save(updatedEmp3);
		
		assertNotNull(updatedEmp3);
		assertThat(updatedEmp3).isNotNull();
		assertEquals("Mahendra", updatedEmp3.getEmpName());
			
	}
	
	@Test
	void DeleteEmp() {
		
		Employee emp1 = new Employee();
		emp1.setEmpId("z004m0dk");
		emp1.setEmpName("morkel");
		emp1.setPassword("user");
		emp1.setEmpType("user");
		emp1.setSalary(35000);
		employeeRepository.save(emp1);
		int id = emp1.getId();
		
		Employee emp2 = new Employee();
		emp2.setEmpId("z004m1dn");
		emp2.setEmpName("hussey");
		emp2.setPassword("user");
		emp2.setEmpType("user");
		emp2.setSalary(35000);
		employeeRepository.save(emp2);
		
		
		employeeRepository.delete(emp1);
	    Optional <Employee> existingEmp = employeeRepository.findById(id);
	    List <Employee> empList = employeeRepository.findAll();
	    
	    assertEquals(1, empList.size());
	    assertThat(existingEmp).isEmpty();		
	}

}
