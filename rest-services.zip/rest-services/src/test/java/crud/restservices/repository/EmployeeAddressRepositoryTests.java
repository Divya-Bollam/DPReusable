package crud.restservices.repository;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.mock.mockito.MockBean;

import crud.restservices.entity.EmployeeAddress;
import crud.restservices.model.EmployeeService;

@DataJpaTest
public class EmployeeAddressRepositoryTests {

	@Autowired
	private EmployeeAddressRepository employeeAddressRepository;
	
	@MockBean
	private EmployeeService employeeService;
	
	EmployeeAddress employeeAddr = new EmployeeAddress();
	
	@BeforeEach
	void before() {
		
		employeeAddr.setAddress1("Chennai");
		employeeAddr.setAddress2("Bangalore");
		employeeAddr.setAddress3("Salem");
	}
	
	@Test
	void create() {
		
    // Arrange
	
		
	// Act
	EmployeeAddress newEmpAddr = employeeAddressRepository.save(employeeAddr);
	
	// Assert
	assertNotNull(newEmpAddr);
	assertThat(newEmpAddr.getAddress1()).isNotNull();
	assertEquals("Salem", newEmpAddr.getAddress3());
	}
	
	@Test
	void getAll() {
		
	//Arrange
	
	employeeAddressRepository.save(employeeAddr);
	EmployeeAddress employeeAddr1 = new EmployeeAddress();
	employeeAddr1.setAddress1("Chengalpet");
	employeeAddr1.setAddress2("Kanchipuram");
	employeeAddr1.setAddress3("Salem");
	employeeAddressRepository.save(employeeAddr1);
	
	// Act 
	
	List <EmployeeAddress> addresses = employeeAddressRepository.findAll();
	
	// Assert
	assertNotNull(addresses);
	//assertEquals(2, addresses.size());
	assertEquals("Chengalpet", addresses.get(1).getAddress1());
		
	}
	
	@Test
	void getById() {
		// Arrange
		
		employeeAddressRepository.save(employeeAddr);
		
		// Act
		
		EmployeeAddress existingAddr = employeeAddressRepository.findById(employeeAddr.getId()).get();		
		
		// Assert
		assertNotNull(existingAddr);
		assertEquals("Bangalore", existingAddr.getAddress2());
	}
	
	@Test
	void update() {
	
	//Arrange
	
	employeeAddressRepository.save(employeeAddr);
	
	//Act
	
	EmployeeAddress existingAddr = employeeAddressRepository.findById(employeeAddr.getId()).get();
	existingAddr.setAddress1("Thrissur");
	existingAddr.setAddress2("Kozhikode");
	existingAddr.setAddress3("Wayanad");
	employeeAddressRepository.save(employeeAddr);
	
	// Assert
	assertNotNull(existingAddr);
	assertEquals("Thrissur", existingAddr.getAddress1());
	}
	
	@Test
	void delete() {
		//Arrange
		
		employeeAddressRepository.save(employeeAddr);
		int id = employeeAddr.getId();
		
		EmployeeAddress employeeAddr1 = new EmployeeAddress();
		employeeAddr1.setAddress1("Kovai");
		employeeAddr1.setAddress2("Madurai");
		employeeAddr1.setAddress3("Dindigul");
		employeeAddressRepository.save(employeeAddr1);
		
		// Act
		
		employeeAddressRepository.delete(employeeAddr);
		Optional<EmployeeAddress> existingEmp = employeeAddressRepository.findById(id);
		List<EmployeeAddress> addrList = employeeAddressRepository.findAll();
		
		//Assert
		assertNotNull(addrList);
		assertEquals(1, addrList.size());
		assertThat(existingEmp).isEmpty();		
	}
}
