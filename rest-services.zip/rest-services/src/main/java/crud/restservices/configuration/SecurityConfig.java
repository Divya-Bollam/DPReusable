package crud.restservices.configuration;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.builders.WebSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;

import crud.restservices.security.EmployeeSecurity;

@Configuration
@EnableWebSecurity
public class SecurityConfig extends WebSecurityConfigurerAdapter {
	@Autowired
	private EmployeeSecurity employeeSecurity;
	
	@Override
	protected void configure(HttpSecurity http) throws Exception {
		// TODO Auto-generated method stub
		http.csrf().disable().authorizeHttpRequests()
//		.antMatchers("/employees").hasRole("ADMIN") // POST
//		.antMatchers("/employees/getall").hasAnyRole("ADMIN","USER") // GET ALL
//		.antMatchers("/employees/**").hasAnyRole("ADMIN","USER") // GET BY ID
//		.antMatchers("/employees/update/**").hasRole("ADMIN") // UPDATE
//		.antMatchers("/employees/delete/**").hasRole("ADMIN") // DELETE
		.antMatchers("/addresses/**/add").hasRole("ADMIN") // POST
		.antMatchers("/addresses").hasAnyRole("ADMIN","USER") // GET ALL
		.antMatchers("/addresses/**").hasAnyRole("ADMIN","USER") // GET BY ID
		.antMatchers("/addresses/**/update/**").hasRole("ADMIN") // UPDATE
		.antMatchers("/addresses/delete/**").hasRole("ADMIN")  // DELETE
		.anyRequest().authenticated().and().httpBasic();
	}
	
	@Override
	public void configure(WebSecurity web) throws Exception {
		web.ignoring().antMatchers("/h2-console/**")
	
		.antMatchers("/employees")
		.antMatchers("/employees/getall")
		.antMatchers("/employees/**")
		.antMatchers("/employees/update/**")
		.antMatchers("/employees/delete/**")
		;
	}

	@Override
	protected void configure(AuthenticationManagerBuilder auth) throws Exception {
		auth.userDetailsService(this.employeeSecurity).passwordEncoder(passwordEncoder());

	}
	
	@Bean
	public PasswordEncoder passwordEncoder() {
		return new BCryptPasswordEncoder();
	}
	
}