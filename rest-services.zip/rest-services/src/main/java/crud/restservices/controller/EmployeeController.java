package crud.restservices.controller;

import java.net.URI;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;

import org.springframework.web.bind.annotation.RestController;

import crud.restservices.entity.Employee;
import crud.restservices.model.EmployeeService;

@RestController
public class EmployeeController {
	
	@Autowired
	private EmployeeService employeeService;
	

	@GetMapping("/employees/getall")
	public ResponseEntity <List<Employee>> getAllEmployees(){
		return ResponseEntity.ok().body(employeeService.getAllEmployees());
	}
	
	@GetMapping("/employees/{id}")
	public ResponseEntity<Employee> getEmployeeById(@PathVariable int id){
		return ResponseEntity.ok().body(employeeService.getEmployeeById(id));
	}
	
	@PostMapping("/employees")
	public ResponseEntity<Employee> createEmployee(@RequestBody Employee employee, URI uri) {
		return ResponseEntity.created(uri).body(this.employeeService.createEmployee(employee));
	}
	
	@PutMapping("/employees/update/{id}")
	public ResponseEntity<Employee> updateEmployee(@PathVariable int id, @RequestBody Employee employee){
		employee.setId(id);
		return ResponseEntity.ok().body(this.employeeService.updateEmployee(employee, id));
	}
	
    @DeleteMapping("/employees/delete/{id}")
    public HttpStatus deleteEmployee(@PathVariable int id){
    	this.employeeService.deleteEmployee(id);
    	return HttpStatus.OK;
    }

    public EmployeeService getEmployeeService() {
    	return employeeService;
    }
    
    public void setEmployeeService(EmployeeService employeeService) {
    	this.employeeService = employeeService;
    }
}
