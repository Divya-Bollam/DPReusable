package crud.restservices.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import crud.restservices.entity.EmployeeAddress;
import crud.restservices.model.EmployeeAddressService;
import crud.restservices.repository.EmployeeAddressRepository;

@RestController
public class EmployeeAddressController {

	@Autowired
	private EmployeeAddressService empAddrService;
	
	@Autowired
	private EmployeeAddressRepository employeeAddressRepository;
	
	@PostMapping("/addresses/{empId}/add")
	public ResponseEntity<EmployeeAddress> createAddress(@RequestBody EmployeeAddress employeeAddress, @PathVariable int empId){
		return ResponseEntity.ok(this.empAddrService.createEmployeeAddress(employeeAddress, empId));
	};
	
	@GetMapping("/addresses")
   public ResponseEntity<List<EmployeeAddress>> getAllAddresses(){
	   return ResponseEntity.ok().body(empAddrService.getAllEmployeeAddresses());
   };
	
   @GetMapping("/addresses/{id}")
	public ResponseEntity<EmployeeAddress> getAddressById(@PathVariable int id){
	   EmployeeAddress employeeAddress = employeeAddressRepository.findById(id).orElseThrow();
	   return ResponseEntity.ok().body(this.empAddrService.getEmployeeAddressById(id));
   };
	
   @PutMapping("/addresses/{empId}/update/{addrId}")
   public ResponseEntity<EmployeeAddress> updateAddress(@PathVariable int addrId, @PathVariable int empId, @RequestBody EmployeeAddress employeeAddress){
	   EmployeeAddress employeeAddr =employeeAddressRepository.findById(empId).orElseThrow(); 
	   employeeAddress.setId(addrId);
	   return ResponseEntity.ok().body(this.empAddrService.updateAddress(employeeAddress, addrId, empId));
   };
	
   @DeleteMapping("/addresses/delete/{id}")
  public HttpStatus	deleteAddress(@PathVariable int id) {
	   this.empAddrService.deleteAddress(id);
	   return HttpStatus.OK;
   };
	
	
}
