package crud.restservices.security;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import crud.restservices.entity.Employee;
import crud.restservices.entity.EmployeeUserDetails;
import crud.restservices.repository.EmployeeRepository;

@Service
public class EmployeeSecurity implements UserDetailsService {
	@Autowired
	private EmployeeRepository employeeRepository;

	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		Optional<Employee> employee =employeeRepository.findByEmpId(username);
        employee.orElseThrow();
		return employee.map(EmployeeUserDetails::new).get();
	}
}
