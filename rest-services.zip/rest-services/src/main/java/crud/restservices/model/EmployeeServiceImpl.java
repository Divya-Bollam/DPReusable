package crud.restservices.model;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import crud.restservices.entity.Employee;
import crud.restservices.exception.ResourceNotFoundException;
import crud.restservices.repository.EmployeeRepository;
//import jakarta.transaction.Transactional;



@Service
@Transactional
public class EmployeeServiceImpl implements EmployeeService  {

	@Autowired
	private EmployeeRepository employeeRepository;

   
   @Autowired
   private PasswordEncoder psEncoder;
	
	@Override
	public Employee createEmployee(Employee employee) {
		
	employee.setPassword(psEncoder.encode(employee.getPassword()));
		
		if(employee.getEmpType().equalsIgnoreCase("admin"))
            employee.setEmpType("ROLE_ADMIN");
        else
            employee.setEmpType("ROLE_USER");
		
		
		return employeeRepository.save(employee);
	}

	@Override
	public List<Employee> getAllEmployees() {
		return this.employeeRepository.findAll();
	}

	@Override
	public Employee getEmployeeById(int EmployeeId) {
		Optional <Employee> employeeDb = this.employeeRepository.findById(EmployeeId);
		if(employeeDb.isPresent()) {
			return employeeDb.get();
		} else {
			throw new ResourceNotFoundException("Record not found with this id, " + EmployeeId);
		}
	}

	@Override
	public Employee updateEmployee(Employee employee, int empId) {
		Employee existingEmployee=employeeRepository.findById(empId).orElseThrow();
	
		
//			Employee employeeUpdate = employeeDb.get();
			existingEmployee.setEmpId(employee.getEmpId());
			existingEmployee.setEmpName(employee.getEmpName());
			
			existingEmployee.setPassword(psEncoder.encode(employee.getPassword()));
			
			if(employee.getEmpType().equalsIgnoreCase("admin"))
				existingEmployee.setEmpType("ROLE_ADMIN");
	        else
	        	existingEmployee.setEmpType("ROLE_USER");
			
			existingEmployee.setSalary(employee.getSalary());
			
			employeeRepository.save(existingEmployee);
			
//			employeeUpdate.setEmpType(employee.getEmpType());
// 	     	employeeUpdate.setAddress(employee.getAddress());
//			employeeUpdate.setSalary(employee.getSalary());
//			employeeRepository.save(employeeUpdate);
		    return existingEmployee;
		 
	}

	@Override
	public void deleteEmployee(int id) {
//		Optional <Employee> employeeDb = this.employeeRepository.findById(id);
//		
//		if(employeeDb.isPresent()) {
//			this.employeeRepository.delete(employeeDb.get());
//		} else {
//			throw new ResourceNotFoundException("Record not found with this id, " + id );
//		}
		
//		Employee existingEmployee = employeeRepository.findById(empid).orElseThrow();
//      employeeRepository.delete(existingEmployee);
		
		Employee existingEmployee = employeeRepository.findById(id).orElseThrow();
		employeeRepository.delete(existingEmployee);
	}

	public EmployeeRepository getEmployeeRepository() {
		return employeeRepository;
	}

	public void setEmployeeRepository(EmployeeRepository employeeRepository) {
		this.employeeRepository = employeeRepository;
	}
	
	
//	public PasswordEncoder getPasswordEncoder() {
//		return psEncoder;
//	}
//	
//	public void setPasswordEncoder(PasswordEncoder passwordEncoder) {
//		this.psEncoder = passwordEncoder;
//	}

}
