package crud.restservices.model;

import java.util.List;
import crud.restservices.entity.Employee;

public interface EmployeeService {
	
	Employee createEmployee(Employee employee);
	
	public List <Employee> getAllEmployees();
	
	Employee getEmployeeById(int EmployeeId);
	
	Employee updateEmployee(Employee employee, int empId);
	
	void deleteEmployee(int id);
	
}
