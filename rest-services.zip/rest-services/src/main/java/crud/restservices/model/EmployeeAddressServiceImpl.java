package crud.restservices.model;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import crud.restservices.entity.Employee;
import crud.restservices.entity.EmployeeAddress;
import crud.restservices.exception.ResourceNotFoundException;
import crud.restservices.repository.EmployeeAddressRepository;
import crud.restservices.repository.EmployeeRepository;
//import jakarta.transaction.Transactional;



@Service
@Transactional
public class EmployeeAddressServiceImpl implements EmployeeAddressService{

	@Autowired
	private EmployeeAddressRepository employeeAddressRepository;
	
	@Autowired
	private EmployeeRepository employeeRepository;
	
	@Override
	public EmployeeAddress createEmployeeAddress(EmployeeAddress empAddress, int empId) {
		 Employee employee = employeeRepository.findById(empId).orElseThrow();
		 empAddress.setEmployee(employee);
		 return this.employeeAddressRepository.save(empAddress);
	}

	@Override
	public List<EmployeeAddress> getAllEmployeeAddresses() {
		return this.employeeAddressRepository.findAll();
	}

	@Override
	public EmployeeAddress getEmployeeAddressById(int id) {
		Optional <EmployeeAddress> empAddrDb = employeeAddressRepository.findById(id); 
		if(empAddrDb.isPresent()) {
			return empAddrDb.get();
		}
		else {
			throw new ResourceNotFoundException("Record not found with this id " + id);
		}
	}

	@Override
	public EmployeeAddress updateAddress(EmployeeAddress employeeAddress, int addrId, int empId) {
		Optional<EmployeeAddress> empAddrDb = this.employeeAddressRepository.findById(employeeAddress.getId());		
	    
		if(empAddrDb.isPresent()) {
	    EmployeeAddress empAddrUpdate = empAddrDb.get(); 	
	    	empAddrUpdate.setAddress1(employeeAddress.getAddress1());
	    	empAddrUpdate.setAddress2(employeeAddress.getAddress2());
	    	empAddrUpdate.setAddress3(employeeAddress.getAddress3());
	        employeeAddressRepository.save(empAddrUpdate);
	        
	     return empAddrUpdate;
	    }
		
		else {
			throw new ResourceNotFoundException("Record not found with this id " + employeeAddress.getId());
		}
	}

	@Override
	public void deleteAddress(int id) {
		Optional <EmployeeAddress> empAddrDb = this.employeeAddressRepository.findById(id);
		if(empAddrDb.isPresent()) {
			this.employeeAddressRepository.delete(empAddrDb.get());
		}
		else {
			throw new ResourceNotFoundException("Record not found with this id " + id);
		}
		
	}

}
