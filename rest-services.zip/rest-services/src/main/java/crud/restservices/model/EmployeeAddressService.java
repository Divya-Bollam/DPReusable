package crud.restservices.model;

import java.util.List;

import crud.restservices.entity.EmployeeAddress;

public interface EmployeeAddressService {
	
	EmployeeAddress createEmployeeAddress (EmployeeAddress empAddress, int empId);
	
	public List <EmployeeAddress> getAllEmployeeAddresses();
	
	EmployeeAddress getEmployeeAddressById(int id);
	
	EmployeeAddress updateAddress(EmployeeAddress employeeAddress, int addrId, int empId);
	
	public void deleteAddress(int id);

}
