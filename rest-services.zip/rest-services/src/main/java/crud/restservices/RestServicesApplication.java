package crud.restservices;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


import crud.restservices.entity.Employee;
import crud.restservices.model.EmployeeService;

@SpringBootApplication
//@ComponentScan({ "crud.restservices.*" })
public class RestServicesApplication implements CommandLineRunner{

	@Autowired
	private EmployeeService employeeService;
	private static Employee employee = new Employee();
	
	
	public static void main(String[] args) {
		SpringApplication.run(RestServicesApplication.class, args);
	}
	
	@Override
	public void run(String... args) throws Exception {
		employee.setEmpId("z004m0dh");
		employee.setEmpName("Syed");
		employee.setPassword("admin");
		employee.setEmpType("admin");
		employee.setSalary(25000);
	
		employeeService.createEmployee(employee);
		
	}

}
