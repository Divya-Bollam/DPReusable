package crud.restservices.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import crud.restservices.entity.Employee;

public interface EmployeeRepository extends JpaRepository<Employee, Integer> {

	Boolean existsByEmpId(String EmpId);
    Optional<Employee> findByEmpId(String empId);

}
