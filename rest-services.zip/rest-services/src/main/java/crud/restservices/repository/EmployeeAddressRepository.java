package crud.restservices.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import crud.restservices.entity.EmployeeAddress;

public interface EmployeeAddressRepository extends JpaRepository<EmployeeAddress, Integer>{

}
